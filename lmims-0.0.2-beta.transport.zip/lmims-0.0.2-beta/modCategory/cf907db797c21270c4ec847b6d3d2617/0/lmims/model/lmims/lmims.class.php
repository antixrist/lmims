<?php
class lmims extends xPDOObject {}
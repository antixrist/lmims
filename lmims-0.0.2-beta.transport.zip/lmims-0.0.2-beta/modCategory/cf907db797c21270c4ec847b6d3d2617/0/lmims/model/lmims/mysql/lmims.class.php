<?php
require_once (dirname(dirname(__FILE__)) . '/lmims.class.php');
class lmims_mysql extends lmims {}